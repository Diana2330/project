import os
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, render_template, request, redirect, url_for, flash, make_response
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash  # Importando o check_password_hash
import locale  # Adicionando a importação do locale
from flask import session
from datetime import datetime, timedelta
from sqlalchemy import text
from flask import jsonify



app = Flask(__name__)
# Caminho absoluto para o banco de dados
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(basedir, 'project.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Para evitar alertas desnecessários
app.secret_key = 'mysecretkey'  # Chave secreta para criptografar as sessõe

# Configura o locale para o Brasil
locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')

# Função para formatar o saldo
@app.template_filter('format_currency')
def format_currency(value):
    return locale.currency(value, grouping=True)

# Inicializa o banco de dados e o Flask-Login
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'  # Página de login para usuários não autenticados

# Função para copiar faturas padrão para um novo usuário
def copiar_faturas_padroes_para_usuario(usuario_id):
    """Copia as faturas padrão do usuário 1 para um novo usuário, ajustando o status para o mês atual."""
    try:
        # Dicionário para mapear os meses para valores numéricos
        meses_para_numero = {
            "janeiro": 1, "fevereiro": 2, "março": 3, "abril": 4, "maio": 5, "junho": 6,
            "julho": 7, "agosto": 8, "setembro": 9, "outubro": 10, "novembro": 11, "dezembro": 12
        }

        # Busca as faturas do usuário padrão (ID = 1)
        faturas_padroes = Fatura.query.filter_by(usuario_id=1).all()

        # Obtém o mês e ano atual do sistema
        hoje = datetime.now()
        mes_atual_num = hoje.month  # Mês atual como número (1-12)
        ano_atual = hoje.year  # Exemplo: 2024

        for fatura in faturas_padroes:
            # Converte o mês da fatura para número
            mes_fatura_num = meses_para_numero[fatura.mes.lower()]

            # Define o status da fatura com base no mês e ano
            if fatura.ano < ano_atual or (fatura.ano == ano_atual and mes_fatura_num < mes_atual_num):
                status = "Fatura Paga"
            elif fatura.ano > ano_atual or (fatura.ano == ano_atual and mes_fatura_num > mes_atual_num):
                status = "Fatura Aberta"
            else:
                status = "Fatura Fechada"

            # Cria uma nova fatura para o novo usuário
            nova_fatura = Fatura(
                usuario_id=usuario_id,
                mes=fatura.mes,
                ano=fatura.ano,
                valor=fatura.valor,
                status=status
            )
            db.session.add(nova_fatura)

        db.session.commit()
    except Exception as e:
        print(f"Erro ao copiar faturas padrão: {e}")

       # Modelo de Fatura
class Fatura(db.Model):
    __tablename__ = 'faturas'  # Nome da tabela no banco de dados

    id = db.Column(db.Integer, primary_key=True)  # Chave primária
    usuario_id = db.Column(db.Integer, nullable=False)  # ID do usuário associado
    mes = db.Column(db.String(20), nullable=False)  # Mês da fatura
    ano = db.Column(db.Integer, nullable=False)  # Ano da fatura
    valor = db.Column(db.Float, nullable=False)  # Valor da fatura
    status = db.Column(db.String(20), nullable=False, default="aberta")  # Status da fatura


    def __repr__(self):
        return f"<Fatura {self.mes}/{self.ano} - {self.status}>"

    # Modelo de Usuário
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    saldo = db.Column(db.Float, default=1000.0)  # Saldo inicial do usuário
    limite_disponivel = db.Column(db.Float, default=1000.0)  # Limite do cartão
    limite_emprestimo = db.Column(db.Float, default=3000.0)
    data_cadastro = db.Column(db.String(50), nullable=False, default=datetime.now().strftime('%Y-%m-%d'))  # Data de cadastro

    def __repr__(self):
        return f'<User {self.username}>'

class Emprestimo(db.Model):
    __tablename__ = 'emprestimos'

    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, nullable=False)
    valor_emprestimo = db.Column(db.Float, nullable=False)
    numero_parcelas = db.Column(db.Integer, nullable=False)
    taxa_juros = db.Column(db.Float, nullable=False)  # Campo adicional
    saldo_devedor = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), nullable=False, default='em andamento')
    data_criacao = db.Column(db.String(50), nullable=False)  # Campo adicional
    data_primeira_parcela = db.Column(db.String(10), nullable=False)

    def __repr__(self):
        return f"<Emprestimo {self.valor_emprestimo} - {self.status}>"

class Parcela(db.Model):
    __tablename__ = 'parcelas'

    id = db.Column(db.Integer, primary_key=True)
    emprestimo_id = db.Column(db.Integer, nullable=False)  # Relaciona à tabela de empréstimos
    numero_parcela = db.Column(db.Integer, nullable=False)  # Número da parcela
    valor_parcela = db.Column(db.Float, nullable=False)  # Valor da parcela
    data_vencimento = db.Column(db.String(10), nullable=False)  # Data de vencimento da parcela
    status = db.Column(db.String(20), nullable=False, default='Pendente')  # Status da parcela (Pendente, Pago, etc.)

    def __repr__(self):
        return f"<Parcela {self.numero_parcela} - {self.status}>"

class Planejamento(db.Model):
    __tablename__ = 'planejamento'

    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, nullable=False)
    nome_meta = db.Column(db.String(200), nullable=False)
    valor_desejado = db.Column(db.Float, nullable=False)
    prazo = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="Em andamento")
    def __repr__(self):
        return f"<Planejamento {self.meta} - {self.valor_desejado}>"



    # Função para carregar o usuário com base no ID da sessão
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.before_request
def make_session_permanent():
    session.permanent = True  # Torna a sessão permanente
    app.permanent_session_lifetime = timedelta(minutes=5)  # Define o tempo de expiração da sessão (opcional)



# Rota para a página de login
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form["username"]
        password = request.form["password"]

        # Verificar se o usuário existe
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password_hash, password):
            # Login bem-sucedido
            login_user(user)  # Autentica o usuário
            flash(f"Login bem-sucedido para {user.username}", "success")
            print(f"Usuário {user.username} autenticado com sucesso")
            return redirect(url_for('home'))  # Redireciona para a página home

        else:
            flash("Credenciais inválidas", "danger")  # Mensagem de erro
            return redirect(url_for('login'))

    return render_template('login.html')  # Página de login

@app.route('/logout')
@login_required
def logout():
    logout_user()  # Faz logout do usuário
    # Exibe uma mensagem de sucesso usando o flash
    flash("Você foi desconectado com sucesso.", "success")
    return redirect(url_for('login'))  # Redireciona para a página de login


# Página inicial do usuário após login
@app.route("/home", methods=['GET', 'POST'])
@login_required  # Garante que o usuário esteja logado para acessar a página
def home():
    username = current_user.username  # Obtém o nome do usuário logado

    resultado = db.session.execute(
        text("SELECT saldo FROM user WHERE id = :usuario_id"),
        {"usuario_id": current_user.id}
    ).fetchone()

    saldo = resultado.saldo if resultado else 0  # Extrai o saldo ou define 0 se não encontrado

    # Cria a resposta com o conteúdo da página
    response = make_response(render_template('home.html', username=username, saldo=saldo))

    # Impede que o navegador armazene em cache a página
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, proxy-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'

    return response

# Rota para a página de registro
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Recebe os dados do formulário
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm-password']

        # Verificar se as senhas coincidem
        if password != confirm_password:
            return "As senhas não coincidem", 400

        # Verificar se o nome de usuário já existe
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return "Nome de usuário já está em uso", 400

        # Criar novo usuário com a senha hash
        password_hash = generate_password_hash(password)  # Gera o hash da senha
        new_user = User(username=username, password_hash=password_hash)
        db.session.add(new_user)
        db.session.commit()

        copiar_faturas_padroes_para_usuario(new_user.id)

        # Redirecionar para a página de login após o registro
        return redirect(url_for('login'))  # Redireciona para a página de login (index)

    return render_template('register.html')  # Exibe o formulário de registro

@app.route('/cartoes', methods=['GET', 'POST'])
@login_required
def cartoes():
    # Consulta as faturas usando o modelo Fatura
    resultado = Fatura.query.filter_by(usuario_id=current_user.id).all()

    # Passa os resultados para o template
    return render_template('cartoes.html', faturas=resultado)


@app.route('/api/faturas', methods=['GET'])
@login_required
def api_faturas():
    try:
        # Busca as faturas do usuário logado
        faturas = Fatura.query.filter_by(usuario_id=current_user.id).all()


        # Converte os resultados para JSON
        dados = {
            "saldo": current_user.saldo,
            "limite_disponivel": current_user.limite_disponivel,
            "faturas": [
                {
                    "id": fatura.id,
                    "mes": fatura.mes,
                    "ano": fatura.ano,
                    "valor": fatura.valor,
                    "status": fatura.status
                } for fatura in faturas
            ]
        }
        return jsonify(dados)

    except Exception as e:
        print(f"Erro ao buscar faturas: {e}")
        return jsonify({'error': 'Erro ao buscar faturas'}), 500

@app.route('/api/pagar_fatura', methods=['POST'])
@login_required
def pagar_fatura():
    try:
        # Recebe o ID da fatura do corpo da requisição
        data = request.get_json()
        fatura_id = data.get('id')

        # Busca a fatura no banco de dados
        fatura = Fatura.query.filter_by(id=fatura_id, usuario_id=current_user.id).first()

        # Verifica se a fatura existe e está no status "Fatura Fechada"
        if not fatura or fatura.status != "Fatura Fechada":
            return jsonify({"error": "Fatura inválida ou não está pronta para pagamento"}), 400

        # Verifica se o saldo da conta é suficiente
        if current_user.saldo < fatura.valor:
            return jsonify({"error": "Saldo insuficiente"}), 400

        # Atualiza os valores
        current_user.saldo -= fatura.valor  # Diminui o saldo da conta
        current_user.limite_disponivel += fatura.valor  # Aumenta o limite disponível do cartão
        fatura.status = "Fatura Paga"  # Atualiza o status da fatura

        # Salva as alterações no banco
        db.session.commit()

        return jsonify({
            "success": True,
            "novo_saldo": current_user.saldo,
            "novo_limite": current_user.limite_disponivel,
            "status_fatura": fatura.status
        })

    except Exception as e:
        print(f"Erro ao processar o pagamento: {e}")
        return jsonify({"error": "Erro interno no servidor"}), 500

@app.route('/planejamento', methods=['GET', 'POST'])
@login_required
def planejamento():
    if request.method == 'POST':
        # Captura os dados do formulário
        nome_meta = request.form.get('nome_meta')
        valor_desejado = request.form.get('valor_desejado')
        prazo = request.form.get('prazo')

        # Validação básica dos campos
        if not nome_meta or not valor_desejado or not prazo:
            flash("Todos os campos são obrigatórios!", "danger")
            return redirect(url_for('planejamento'))

        try:
            # Criação de uma nova meta financeira
            nova_meta = Planejamento(
                usuario_id=current_user.id,
                nome_meta=nome_meta,
                valor_desejado=float(valor_desejado),
                prazo=int(prazo)
             
            )
            db.session.add(nova_meta)
            db.session.commit()
            flash("Meta financeira adicionada com sucesso!", "success")
        except Exception as e:
            db.session.rollback()
            flash(f"Erro ao adicionar a meta: {e}", "danger")

        return redirect(url_for('planejamento'))

    try:
        # Consulta todas as metas do usuário logado
        metas = Planejamento.query.filter_by(usuario_id=current_user.id).all()
    except Exception as e:
        metas = []
        flash(f"Erro ao carregar metas: {e}", "danger")

    return render_template('planejamento.html', metas=metas)

@app.route('/emprestimo')
@login_required
def emprestimo():
    # Recuperar o ID do usuário logado
    usuario_id = current_user.id

    # Buscar limite de empréstimo e saldo atual do usuário
    resultado_user = db.session.execute(
        text("SELECT saldo, limite_emprestimo FROM user WHERE id = :usuario_id"),
        {"usuario_id": usuario_id}
    ).fetchone()

    saldo_disponivel = resultado_user.saldo if resultado_user else 0
    limite_emprestimo = resultado_user.limite_emprestimo if resultado_user else 0

    # Buscar histórico de empréstimos
    emprestimos = db.session.execute(
        text("""
            SELECT valor_emprestimo, numero_parcelas, saldo_devedor, status
            FROM emprestimos WHERE usuario_id = :usuario_id
        """),
        {"usuario_id": usuario_id}
    ).fetchall()

    # Renderizar a página com os dados
    return render_template(
        "emprestimo.html",
        limite_emprestimo=limite_emprestimo,
        saldo_disponivel=saldo_disponivel,
        emprestimos=emprestimos,
    )

@app.route('/emprestimo_confirmar', methods=['POST'])
@login_required
def emprestimo_confirmar():
    try:
        # Etapa 1: Capturar os dados do formulário
        print("Etapa 1: Recebendo dados do formulário")
        valor_emprestimo = float(request.form.get('valor-emprestimo'))
        numero_parcelas = int(request.form.get('numero-parcelas'))
        data_vencimento = request.form.get('data-vencimento')

        # Etapa 2: Validação dos dados
        print("Etapa 2: Validação dos dados")
        if valor_emprestimo < 100 or valor_emprestimo > 3000:
            print("Erro na validação: Valor do empréstimo inválido")
            flash("O valor do empréstimo deve estar entre R$ 100,00 e R$ 3.000,00.", "danger")
            return redirect(url_for('emprestimo'))

        if valor_emprestimo > current_user.limite_emprestimo:
            print("Erro na validação: Valor do empréstimo excede o limite")
            flash("O valor do empréstimo excede o limite disponível.", "danger")
            return redirect(url_for('emprestimo'))

        # Calcular juros e valores
        print("Etapa 3: Cálculo dos juros e valores")
        if numero_parcelas <= 4:
            juros_percentual = 0.02
        elif numero_parcelas <= 8:
            juros_percentual = 0.04
        else:
            juros_percentual = 0.06

        valor_total_com_juros = valor_emprestimo * (1 + juros_percentual)
        valor_parcela = valor_total_com_juros / numero_parcelas
        data_vencimento_dt = datetime.strptime(data_vencimento, '%d/%m/%Y')

        # Registrar o empréstimo no banco
        print("Etapa 4: Registro do empréstimo no banco")
        novo_emprestimo = Emprestimo(
            usuario_id=current_user.id,
            valor_emprestimo=valor_emprestimo,
            numero_parcelas=numero_parcelas,
            taxa_juros=juros_percentual,
            saldo_devedor=valor_total_com_juros,
            status="Ativo",
            data_primeira_parcela=data_vencimento,
            data_criacao=datetime.now().strftime('%Y-%m-%d')
        )
        db.session.add(novo_emprestimo)
        db.session.flush()  # Garante que o ID do empréstimo seja gerado

        # Registrar as parcelas no banco
        print("Etapa 5: Registro das parcelas no banco")
        for i in range(1, numero_parcelas + 1):
            data_vencimento_parcela = (data_vencimento_dt + timedelta(days=30 * i)).strftime('%Y-%m-%d')
            nova_parcela = Parcela(
                emprestimo_id=novo_emprestimo.id,
                numero_parcela=i,
                valor_parcela=round(valor_parcela, 2),
                data_vencimento=data_vencimento_parcela,
                status="Pendente"
            )
            db.session.add(nova_parcela)

        # Atualizar saldo e limite do usuário
        print("Etapa 6: Atualização do saldo e limite do usuário")
        current_user.saldo += valor_emprestimo
        current_user.limite_emprestimo -= valor_emprestimo

        # Confirmar as alterações
        print("Etapa 7: Commit no banco de dados")
        db.session.commit()

        flash("Empréstimo confirmado com sucesso!", "success")
        return redirect(url_for('emprestimo'))

    except Exception as e:
        print(f"Erro na rota emprestimo_confirmar: {e}")
        db.session.rollback()
        flash(f"Erro ao confirmar o empréstimo: {e}", "danger")
        return redirect(url_for('emprestimo'))

@app.route('/extrato')
@login_required
def extrato():
    # Definir a data fixa para filtro
    data_inicio = '2024-12-01'

    # Recuperar o saldo atual do usuário
    saldo_atual = current_user.saldo

    # Buscar pagamentos de faturas
    pagamentos = db.session.execute(
    text("""
        SELECT mes || '/' || ano AS data, valor AS valor, 'Pagamento de Fatura' AS descricao
        FROM faturas
        WHERE usuario_id = :usuario_id AND status = 'Fatura Paga' AND
              (ano > 2024 OR (ano = 2024 AND
              CASE
                  WHEN mes = 'Janeiro' THEN 1
                  WHEN mes = 'Fevereiro' THEN 2
                  WHEN mes = 'Março' THEN 3
                  WHEN mes = 'Abril' THEN 4
                  WHEN mes = 'Maio' THEN 5
                  WHEN mes = 'Junho' THEN 6
                  WHEN mes = 'Julho' THEN 7
                  WHEN mes = 'Agosto' THEN 8
                  WHEN mes = 'Setembro' THEN 9
                  WHEN mes = 'Outubro' THEN 10
                  WHEN mes = 'Novembro' THEN 11
                  WHEN mes = 'Dezembro' THEN 12
              END >= 12))
    """),
    {"usuario_id": current_user.id}
).fetchall()


    # Buscar empréstimos realizados a partir de dezembro de 2024
    emprestimos = db.session.execute(
        text("""
            SELECT data_criacao AS data, valor_emprestimo AS valor, 'Empréstimo Realizado' AS descricao
            FROM emprestimos
            WHERE usuario_id = :usuario_id AND data_criacao >= :data_inicio
        """),
        {"usuario_id": current_user.id, "data_inicio": data_inicio}
    ).fetchall()

    # Combinar as movimentações
    movimentacoes = list(pagamentos) + list(emprestimos)

    # Ordenar por data
    movimentacoes.sort(key=lambda x: x.data)

    # Renderizar o template com as movimentações
    return render_template('extrato.html', movimentacoes=movimentacoes, saldo_atual=saldo_atual)

@app.route('/investimento')
@login_required
def investimento():
    return render_template('investimento.html')

