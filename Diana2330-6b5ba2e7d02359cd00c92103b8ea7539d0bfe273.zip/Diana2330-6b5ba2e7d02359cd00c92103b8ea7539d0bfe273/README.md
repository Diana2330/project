# InovaBank: Soluções Financeiras Inteligentes

#### Video Demo: [Assista aqui](https://youtube.com/suavideo)

#### Description:
O **InovaBank** é um banco fictício criado como projeto final para o curso CS50. Ele oferece uma plataforma integrada de gestão financeira com funcionalidades como:
- Gerenciamento de faturas de cartão de crédito.
- Simulação e acompanhamento de empréstimos.
- Planejamento financeiro com metas personalizadas.
- Consulta de extratos de movimentações.

#### Files:
- `app.py`: Código principal do backend do sistema.
- `templates/`: Contém os arquivos HTML que estruturam as páginas do site.
- `static/`: Armazena arquivos CSS e JavaScript para o frontend.
- `project.db`: Banco de dados SQLite usado para armazenar informações do usuário.

#### Design Decisions:
Optei por usar Flask como framework para o backend devido à sua simplicidade e flexibilidade. O banco de dados foi implementado em SQLite por ser leve e adequado para este projeto. Para o frontend, utilizei HTML, CSS e JavaScript para criar uma interface amigável.

#### How It Works:
- O usuário pode se registrar e fazer login.
- Após o login, recebe um saldo inicial de R$1.000 para testar as funcionalidades.
- As funcionalidades incluem: visualização de faturas, simulação de empréstimos e planejamento financeiro.

#### How to Run:
Este projeto foi projetado para rodar no ambiente **CS50 Codespaces**.

https://github.com/code50/184691051/blob/b2106f6d901e29f7d5172375753918dddb5405fe/project
[code50](https://github.com/code50/184691051/blob/b2106f6d901e29f7d5172375753918dddb5405fe/project)
https://github.com/code50/184691051/blob/main/project
