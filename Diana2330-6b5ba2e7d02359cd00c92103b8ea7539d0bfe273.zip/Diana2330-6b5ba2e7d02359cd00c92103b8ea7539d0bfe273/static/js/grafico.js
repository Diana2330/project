// Variáveis globais
let dadosFaturas = []; // Dados das faturas
let saldoConta = 0; // Saldo disponível na conta
let limiteTotal = 1000; // Limite total do cartão
let mesAtual = 0; // Índice do mês atual

// Função para buscar os dados da API
async function buscarDados() {
    try {
        const response = await fetch('/api/faturas'); // Busca os dados da API
        const { faturas, saldo, limite_disponivel } = await response.json(); // Recebe as faturas e o saldo

        dadosFaturas = faturas;
        saldoConta = saldo; // Atualiza o saldo global
        limiteTotal = limite_disponivel

        if (dadosFaturas.length > 0) {
            // Obtém o mês atual
            const hoje = new Date();
            const mesAtualNome = hoje.toLocaleString("pt-BR", { month: "long" });
            const anoAtual = hoje.getFullYear();

            mesAtual = dadosFaturas.findIndex(
                fatura =>
                    fatura.mes.toLowerCase() === mesAtualNome.toLowerCase() &&
                    fatura.ano === anoAtual
            );

            if (mesAtual === -1) mesAtual = 0; // Define o primeiro mês se não encontrar
            atualizarGrafico(); // Atualiza o gráfico

        } else {
            console.error("Nenhuma fatura encontrada.");
        }
    } catch (error) {
        console.error("Erro ao buscar dados da API:", error);
    }
}

// Função para calcular o limite utilizado
function calcularLimiteUtilizado() {
    return dadosFaturas
        .filter(fatura => fatura.status !== "Fatura Paga") // Considera apenas faturas não pagas
        .reduce((valor, fatura) => valor + fatura.valor, 0);
}

// Função principal para atualizar o gráfico e a página
function atualizarGrafico() {
    if (!dadosFaturas || dadosFaturas.length === 0) {
        console.error("Nenhum dado disponível para atualizar o gráfico.");
        return;
    }

    const fatura = dadosFaturas[mesAtual];
    if (!fatura) {
        console.error("Fatura atual inválida.");
        return;
    }

    // Seletores
    const barras = document.querySelectorAll(".chart-bar");
    const navegacao = document.querySelector("#month-display");
    const chartAmount = document.querySelector("#total-fatura");
    const chartStatus = document.querySelector("#chart-status");
    const limiteUtilizadoTexto = document.querySelector(".limite-utilizado .valor");
    const limiteDisponivelTexto = document.querySelector(".limite-disponivel .valor");
    const botaoPagar = document.querySelector("#botaopagar");

    // Atualiza os valores no HTML
    chartAmount.textContent = `R$ ${fatura.valor.toFixed(2).replace(".", ",")}`;
    chartStatus.textContent = fatura.status;
    navegacao.textContent = `${fatura.mes} ${fatura.ano}`;

    const limiteUtilizado = calcularLimiteUtilizado();
    limiteUtilizadoTexto.textContent = `R$ ${limiteUtilizado.toFixed(2).replace(".", ",")}`;
    limiteDisponivelTexto.textContent = `R$ ${(limiteTotal - limiteUtilizado).toFixed(2).replace(".", ",")}`;

    // Atualiza as barras do gráfico
    barras.forEach((barra, index) => {
        const indice = mesAtual - 2 + index; // Determina o índice relativo
        if (indice >= 0 && indice < dadosFaturas.length) {
            barra.style.height = `${dadosFaturas[indice].valor / 10}px`;
            barra.style.backgroundColor =
                indice === mesAtual ? "#8b0000" : indice < mesAtual ? "#e95d98" : "#f0abcc";
        } else {
            barra.style.height = "0px"; // Esconde barras fora do intervalo
        }
    });

    // Exibe ou oculta o botão de pagar fatura
    if (fatura.status === "Fatura Fechada") {
        botaoPagar.style.display = "block";
    } else {
        botaoPagar.style.display = "none";
    }
}

// Funções para navegação entre meses
function proximoMes() {
    if (mesAtual < dadosFaturas.length - 1) {
        mesAtual++;
        atualizarGrafico();
    }
}

function mesAnterior() {
    if (mesAtual > 0) {
        mesAtual--;
        atualizarGrafico();
    }
}

// Adiciona eventos aos botões
document.addEventListener("DOMContentLoaded", () => {
    const botaoProximo = document.querySelector("#next-month");
    const botaoAnterior = document.querySelector("#prev-month");
    const botaoPagar = document.querySelector("#botaopagar");

    // Adiciona eventos de navegação
    if (botaoProximo && botaoAnterior) {
        botaoProximo.addEventListener("click", proximoMes);
        botaoAnterior.addEventListener("click", mesAnterior);
    }

    // Adiciona eventos para pagamento
    if (botaoPagar) {
        botaoPagar.addEventListener("click", () => {
            const fatura = dadosFaturas[mesAtual];
            if (fatura.status === "Fatura Fechada") {
                document.querySelector("#popup-pagamento").style.display = "flex";
                document.querySelector("#valor-fatura-popup").textContent = `Valor da Fatura: R$ ${fatura.valor.toFixed(2).replace(".", ",")}`;
                document.querySelector("#saldo-disponivel-popup").textContent = `Saldo Disponível: R$ ${saldoConta.toFixed(2).replace(".", ",")}`;
            }
        });

        document.querySelector("#cancelar-pagamento").addEventListener("click", () => {
            document.querySelector("#popup-pagamento").style.display = "none";
        });

        document.querySelector("#confirmar-pagamento").addEventListener("click", async () => {
            const fatura = dadosFaturas[mesAtual];
            try {
                const response = await fetch(`/api/pagar_fatura`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({ id: fatura.id }),
                });

                if (response.ok) {
                    const data = await response.json(); // Recebe os valores atualizados do servidor

                    // Atualiza os valores localmente
                    fatura.status = "Fatura Paga";
                    saldoConta = data.novo_saldo;
                    limiteTotal = data.novo_limite;

                    // Recarrega os dados para refletir as mudanças no gráfico
                    await buscarDados();

                    alert("Pagamento realizado com sucesso!");
                } else {
                    alert("Erro ao realizar o pagamento.");
                }
            } catch (error) {
                console.error("Erro ao processar o pagamento:", error);
            }

            document.querySelector("#popup-pagamento").style.display = "none";
        });
    }

    // Inicializa os dados
    buscarDados();
});
